find_sequence(Graph1, Graph2, Start, Target, K, Sequence) :-
    %% TODO: remove fail and add body/other cases for this predicate
    fail.